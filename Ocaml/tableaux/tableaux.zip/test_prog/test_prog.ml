open OUnit2
open Test_func 
  
let id x = x

let test_string_ltl (name:string) (exp_output:string) (input:ltl)=
  name>::(fun _ -> assert_equal exp_output (string_ltl input) ~printer:id)

let test_is_poised (name:string) (exp_output:bool) (input: ltl list)=
  name>::(fun _->assert_equal exp_output (is_poised input) ~printer:string_of_bool)


let test_main_op (name:string) (exp_output:ltl_op) (input: ltl)=
  name>::(fun _->assert_equal exp_output (main_op input) ~printer:string_ltl_op)

let test_get_rid_Unary (name:string)(exp_output:ltl list)(input_list:ltl list)(input_op:ltl_op)=
  name>::(fun _->assert_equal exp_output (get_rid_Unary input_op input_list) ~printer:string_ltl_list)

let test_get_rid_Binary (name:string)(exp_output:ltl list)(input_list : ltl list)(input_op:ltl_op)(input_bool:bool)=
  name>::(fun _->assert_equal exp_output (get_rid_Binary input_op input_list input_bool) ~printer:string_ltl_list)

let tests = "Tests" >::: [
  (*tests for string_ltl*)
  test_string_ltl "string_ltl Prop" "P" P;
  test_string_ltl "string_ltl Neg F (And)" "Neg(F((P)^(Q)))" (Neg(F(And(P,Q))));
  test_string_ltl "string_ltl X Or G" "(X(T))u(G(B))" (Or(X Top,G Bot));

  (*tests for is_poised*)
  test_is_poised "is_poised P and XP" true [P;X P];
  test_is_poised "is_poised Empty" false [];
  test_is_poised "is_poised Contradicted" false [P;Q;X P;Neg Q];

  (*tests for main_op*)
  test_main_op "main_op Neg P" Prop_op (Neg P);
  test_main_op "main_op And" And_op (And(Neg Q,X(Neg P)));
  test_main_op "main_op Double Neg" NNeg_op (Neg(Neg(Neg Q)));

  (*tests for get_rid_Unary*)
  test_get_rid_Unary "get_rid_Unary Neg F" [P;Neg(And(P,Q));X(Neg(F(And(P,Q))));Or(X Top,G Bot)] [P;Neg(F(And(P,Q)));Or(X Top,G Bot)] NF_op ;
  test_get_rid_Unary "get_rid_Unary And" [P;P;Q;Or(X Top,G Bot)] [P;And(P,Q);Or(X Top,G Bot)] And_op;

  (*tests for get_rid_Binary*)
  test_get_rid_Binary "get_rid_Binary Neg G case 1" [P;Neg(And(P,Q));Or(X Top,G Bot)] [P;Neg(G(And(P,Q)));Or(X Top,G Bot)] NG_op false ;
  test_get_rid_Binary "get_rid_Binary Neg G case 2" [P;X(Neg(G(And(P,Q))));Or(X Top,G Bot)] [P;Neg(G(And(P,Q)));Or(X Top,G Bot)] NG_op true ;
  test_get_rid_Binary "get_rid_Binary Or case 1" [P;Neg(G(And(P,Q)));X Top] [P;Neg(G(And(P,Q)));Or(X Top,G Bot)] Or_op false ;
  test_get_rid_Binary "get_rid_Binary Or case 2" [P;Neg(G(And(P,Q)));G Bot] [P;Neg(G(And(P,Q)));Or(X Top,G Bot)] Or_op true;





  ]

let _ = run_test_tt_main tests